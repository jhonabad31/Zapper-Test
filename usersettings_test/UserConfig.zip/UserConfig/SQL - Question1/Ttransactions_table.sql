USE [Trans_TestDB]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Transactions_Table](
	[TransactionNumber] [nvarchar](50) NULL,
	[ItemID] [nvarchar](50) NULL,
	[ItemName] [nvarchar](max) NULL,
	[ItemQuantity] [nvarchar](50) NULL,
	[ItemTotal] [nvarchar](50) NULL,
	[MerchantID] [nvarchar](50) NULL,
	[CustomerID] [nvarchar](50) NULL,
	[TransactionTimeDate] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


